# Meu Front

Este projeto foi desenvolvido a partir do material didático da Disciplina **Desenvolvimento Full Stack Básico** 

O objetivo deste projeto é apresentar uma aplicação em Front-end a qual representa uma plataforma de busca de veículos tal qual plataformas hoje existentes na internet. Nesta plataforma é possível adicionar carros, fazer uma busca por um modelo específico, listar os modelos disponiveis e tambem excluir ou deletar um determinado modelo.

---
## Como executar

Para executar a aplicação basta fazer o download do projeto e abrir o arquivo index.html no seu browser.
